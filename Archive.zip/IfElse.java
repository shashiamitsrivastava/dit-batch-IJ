public class IfElse {
  public static void main(String[] args) {
    // Simple if else
    // if(true){

    // }
    // else{

    // }
    //  if (){
        
    // }
    // else  if(){

    // }
    // else{

    // }
    // if(){
    //     if(){

    //     }
    //     else{

    //     }
    // }
    // else{

    // }
    
  }  
}
