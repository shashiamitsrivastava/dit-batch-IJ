public class SwitchCaseDemo {

    static int getPrice(){
        String item = "burger";
        switch(item){
            case "burger":
            return 100;
            case "drink":
            return 200;
            default:
            return 0;


        }
    }

    public static void main(String[] args) {
        //System.out.println(getPrice());
        String item = "burger";
        System.out.println(switch(item){
            case "burger","pizza"->100;
            case "drink"->200;
            default->0;
        });
        // Java 14 
        // Colon vs Arrow
        // Java 7 
      
        switch(item){
            case "burger":
            System.out.println("Price is Rs 100");
            case "drink":
            System.out.println("Price is Rs 200");


        }
        // int item = 1;
        // final int BURGER = 1;
        // final int DRINK = 2;
        // final int DESSERT = 3;
        // switch(item){
        //     case BURGER:
        //         System.out.println("Price is Rs 100");
        //     case DRINK:
        //     System.out.println("Price is rs 200");   
        //     case DESSERT:
        //     System.out.println("Price is Rs 150");
        //     default:
        //     System.out.println("50 % off"); 
        // }

    }
}
